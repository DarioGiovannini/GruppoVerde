CREATE DATABASE  IF NOT EXISTS `mediaworldgruppoverde` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `mediaworldgruppoverde`;
-- MySQL dump 10.16  Distrib 10.1.35-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: mediaworldgruppoverde
-- ------------------------------------------------------
-- Server version	10.1.35-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary table structure for view `carichirimini`
--

DROP TABLE IF EXISTS `carichirimini`;
/*!50001 DROP VIEW IF EXISTS `carichirimini`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `carichirimini` (
  `Descrizione` tinyint NOT NULL,
  `Quantita` tinyint NOT NULL,
  `Data` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `giacenzemilano`
--

DROP TABLE IF EXISTS `giacenzemilano`;
/*!50001 DROP VIEW IF EXISTS `giacenzemilano`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `giacenzemilano` (
  `Prodotto` tinyint NOT NULL,
  `Prezzo` tinyint NOT NULL,
  `Quantita` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `maggiorcosto`
--

DROP TABLE IF EXISTS `maggiorcosto`;
/*!50001 DROP VIEW IF EXISTS `maggiorcosto`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `maggiorcosto` (
  `Prodotto` tinyint NOT NULL,
  `Prezzo` tinyint NOT NULL,
  `Quantita` tinyint NOT NULL,
  `Magazzino` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `tblcarichi`
--

DROP TABLE IF EXISTS `tblcarichi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcarichi` (
  `idCarico` int(11) NOT NULL AUTO_INCREMENT,
  `idProdotto` int(11) NOT NULL,
  `idMagazzino` int(11) NOT NULL,
  `Quantita` int(11) NOT NULL,
  `Data` char(8) NOT NULL,
  PRIMARY KEY (`idCarico`),
  KEY `idProdotto` (`idProdotto`),
  KEY `idMagazzino` (`idMagazzino`),
  CONSTRAINT `idMagazzino` FOREIGN KEY (`idMagazzino`) REFERENCES `tblmagazzini` (`idMagazzino`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `idProdotto` FOREIGN KEY (`idProdotto`) REFERENCES `tblprodotti` (`idprodotto`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=138 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcarichi`
--

LOCK TABLES `tblcarichi` WRITE;
/*!40000 ALTER TABLE `tblcarichi` DISABLE KEYS */;
INSERT INTO `tblcarichi` VALUES (1,1,1,23,'20018111'),(58,1,1,11,'20018111'),(59,3,2,22,'20001111'),(60,4,1,32,'20181111'),(61,4,2,123,'20191111'),(62,5,3,432,'20101111'),(63,6,1,123,'20001111'),(64,11,1,4332,'20201111'),(65,7,3,324,'20001111'),(66,12,2,123,'20001111'),(67,8,3,123,'20001111'),(68,9,2,43,'20181111'),(69,10,1,75,'20181111'),(70,11,1,-34,'20001111'),(71,12,3,-52,'20001111'),(72,15,2,365,'20001111'),(73,13,2,74,'20001111'),(74,14,3,456,'20001111'),(75,15,1,345,'20001111'),(76,16,1,6452,'20001111'),(77,17,1,86,'20180131'),(78,16,1,546,'20001111'),(79,16,2,35,'20001111'),(80,18,2,54,'20001111'),(81,19,3,78,'20001111'),(82,20,3,2314,'20001111'),(83,20,3,346,'20001111'),(84,2,2,637,'20001111'),(85,10,1,20,'20180321'),(86,17,2,45,'20180512'),(87,17,3,30,'20181021'),(88,17,1,-20,'20171023'),(89,12,2,40,'20161121'),(90,3,2,20,'20140212'),(91,1,3,160,'20130104'),(92,2,3,200,'20140205'),(93,4,3,500,'20030321'),(94,3,3,200,'20010121'),(95,19,1,450,'19971229'),(96,11,3,8000,'20110211'),(97,14,1,130,'20080403'),(98,18,1,200,'20140706'),(99,15,3,1500,'19850102'),(100,14,1,80,'20180303'),(101,18,1,120,'20180711'),(102,19,1,1800,'20180921'),(103,20,1,190,'20180113'),(104,5,3,908,'19781116'),(105,8,3,750,'20081202'),(106,9,1,70,'20180223'),(107,1,3,500,'19991002'),(108,2,3,255,'19810911'),(109,3,3,308,'20030613'),(110,4,3,411,'20060814'),(111,5,3,300,'20120515'),(112,8,1,16,'20180826'),(113,6,3,1890,'20171228'),(114,7,3,1430,'20150412'),(115,8,3,260,'20140828'),(116,9,3,780,'20010830'),(117,10,3,200,'19881009'),(118,11,1,100,'20180130'),(119,12,1,40,'20180614'),(120,13,1,380,'20180901'),(121,14,1,15,'20181112'),(122,11,3,620,'20030312'),(123,12,3,490,'20070618'),(124,13,3,511,'20150812'),(125,14,3,780,'20100928'),(126,15,3,902,'20131007'),(127,16,3,1200,'20111118'),(128,15,1,15,'20180720'),(129,16,1,28,'20181124'),(130,17,1,40,'20181204'),(131,18,1,120,'20181008'),(132,19,1,155,'20180927'),(133,20,1,160,'20180522'),(134,17,3,8010,'20030811'),(135,18,3,600,'19910416'),(136,19,3,710,'19920718'),(137,20,3,572,'19730802');
/*!40000 ALTER TABLE `tblcarichi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmagazzini`
--

DROP TABLE IF EXISTS `tblmagazzini`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmagazzini` (
  `idMagazzino` int(11) NOT NULL AUTO_INCREMENT,
  `Nome` varchar(45) NOT NULL,
  PRIMARY KEY (`idMagazzino`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmagazzini`
--

LOCK TABLES `tblmagazzini` WRITE;
/*!40000 ALTER TABLE `tblmagazzini` DISABLE KEYS */;
INSERT INTO `tblmagazzini` VALUES (1,'Rimini'),(2,'Roma'),(3,'Milano');
/*!40000 ALTER TABLE `tblmagazzini` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblprodotti`
--

DROP TABLE IF EXISTS `tblprodotti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblprodotti` (
  `idProdotto` int(11) NOT NULL AUTO_INCREMENT,
  `Prezzo` double NOT NULL,
  `Descrizione` varchar(450) NOT NULL,
  PRIMARY KEY (`idProdotto`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblprodotti`
--

LOCK TABLES `tblprodotti` WRITE;
/*!40000 ALTER TABLE `tblprodotti` DISABLE KEYS */;
INSERT INTO `tblprodotti` VALUES (1,320,'Tv'),(2,120,'Telefono'),(3,200,'Schermo'),(4,220,'Ferro'),(5,111,'Pupazzi'),(6,2050,'Magilie'),(7,150,'Carta'),(8,300,'Sedia'),(9,450,'Lavagna'),(10,983,'Gesso'),(11,30,'Pietra'),(12,2004,'Tavolo'),(13,87,'Scarpa'),(14,444,'Statua'),(15,242,'Acqua'),(16,5666,'Tomba'),(17,9987,'Macchina'),(18,22,'Braccialetto'),(19,1000,'Bandiera'),(20,300,'Cavallo');
/*!40000 ALTER TABLE `tblprodotti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `carichirimini`
--

/*!50001 DROP TABLE IF EXISTS `carichirimini`*/;
/*!50001 DROP VIEW IF EXISTS `carichirimini`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `carichirimini` AS select `tblprodotti`.`Descrizione` AS `Descrizione`,`tblcarichi`.`Quantita` AS `Quantita`,`tblcarichi`.`Data` AS `Data` from ((`tblprodotti` join `tblcarichi` on((`tblprodotti`.`idProdotto` = `tblcarichi`.`idProdotto`))) join `tblmagazzini` on((`tblmagazzini`.`idMagazzino` = `tblcarichi`.`idMagazzino`))) where ((`tblmagazzini`.`Nome` like 'Rimini') and (`tblcarichi`.`Data` < 20190000) and (`tblcarichi`.`Data` >= 20180000) and (`tblcarichi`.`Quantita` > 0)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `giacenzemilano`
--

/*!50001 DROP TABLE IF EXISTS `giacenzemilano`*/;
/*!50001 DROP VIEW IF EXISTS `giacenzemilano`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `giacenzemilano` AS select `tblprodotti`.`Descrizione` AS `Prodotto`,`tblprodotti`.`Prezzo` AS `Prezzo`,sum(`tblcarichi`.`Quantita`) AS `Quantita` from ((`tblprodotti` join `tblcarichi` on((`tblprodotti`.`idProdotto` = `tblcarichi`.`idProdotto`))) join `tblmagazzini` on((`tblmagazzini`.`idMagazzino` = `tblcarichi`.`idMagazzino`))) where (`tblmagazzini`.`Nome` like 'Milano') group by `tblprodotti`.`Descrizione` having (`Quantita` > 150) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `maggiorcosto`
--

/*!50001 DROP TABLE IF EXISTS `maggiorcosto`*/;
/*!50001 DROP VIEW IF EXISTS `maggiorcosto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `maggiorcosto` AS select `tblprodotti`.`Descrizione` AS `Prodotto`,max(`tblprodotti`.`Prezzo`) AS `Prezzo`,sum(`tblcarichi`.`Quantita`) AS `Quantita`,`tblmagazzini`.`Nome` AS `Magazzino` from ((`tblprodotti` join `tblcarichi` on((`tblprodotti`.`idProdotto` = `tblcarichi`.`idProdotto`))) join `tblmagazzini` on((`tblmagazzini`.`idMagazzino` = `tblcarichi`.`idMagazzino`))) where (`tblprodotti`.`Prezzo` = (select max(`tblprodotti`.`Prezzo`) AS `Prezzo` from `tblprodotti`)) group by `tblmagazzini`.`Nome` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-09-27 15:50:45
